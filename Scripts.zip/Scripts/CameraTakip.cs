using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraTakip : MonoBehaviour
{
    Vector3 kameraGeciciKonum;
    Vector3 bhizi = Vector3.zero;
    [SerializeField]
    GameObject kaya;

    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        kameraGeciciKonum = transform.position;
        kameraGeciciKonum.x = kaya.transform.position.x;
        kameraGeciciKonum.y = kaya.transform.position.y+4;
        kameraGeciciKonum.z = kaya.transform.position.z-6;
        transform.position = Vector3.SmoothDamp(transform.position, kameraGeciciKonum, ref bhizi, 0.3f);
        transform.LookAt(kaya.transform);
    }
}
