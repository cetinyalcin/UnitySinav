using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KayaHareket : MonoBehaviour
{
    [SerializeField]
    private Animator kanim;

    float gidisHizi = 15f;
    float donusHizi = 10f;
    int durum = 0;
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        float don = Input.GetAxisRaw("Horizontal");
        float git = Input.GetAxisRaw("Vertical");
        if (git == 1 || git == -1)
        {
            durum = 1;
        }
        else if (git == 0 && !Input.anyKey)
        {
            durum = 0;
        }
        kanim.SetInteger("gidis", durum);
        Debug.Log("durum " + durum);
        transform.Translate(Vector3.forward * git * Time.deltaTime * gidisHizi);
        transform.Rotate(Vector3.up * Time.deltaTime * donusHizi * don * donusHizi);
    }

}
