using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Carpismalar : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter(Collision other) {
        Debug.Log(other.gameObject.name+"Çarptı");
        if(other.gameObject.tag=="kutu"){
            Destroy(other.gameObject);
        }
    }
    private void OnCollisionStay(Collision other) {
        Debug.Log(other.gameObject.name+"Çarpma Devam Ediyor ");
    }
    private void OnCollisionExit(Collision other) {
        Debug.Log(other.gameObject.name+"Çarpma Bitti");
    }

    private void OnTriggerEnter(Collider other) {
         Debug.Log(other.gameObject.name+" Trigger Çarptı");
    }

    private void OnTriggerStay(Collider other) {
          Debug.Log(other.gameObject.name+" Trigger Çarpma Devam Ediyor ");
    }
    private void OnTriggerExit(Collider other) {
          Debug.Log(other.gameObject.name+" Trigger Çarpma Bitti");
    }
}
