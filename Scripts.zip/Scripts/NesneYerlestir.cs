using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class NesneYerlestir : MonoBehaviour
{
    GameObject evler;
    GameObject agaclar;
    
    void Start()
    {
        GameObject ev=(GameObject)PrefabUtility.InstantiatePrefab(evler);
        ev.gameObject.transform.position.x=3;


    }

    
    void Update()
    {
        
    }
}
